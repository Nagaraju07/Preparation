namespace UtilityMethods
{
	public class MultClass
	{
		public static int Multiply(int num1, int num2)
		{
			return num1 * num2;
		}
	}
}